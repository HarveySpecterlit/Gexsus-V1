#pragma once

namespace hooking {
    bool init();
    bool destroy();
}